import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

// ============================================================
// Utilities
// ============================================================

function getWorkspaceRoot(): string | undefined {
  return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
}

function getConfig() {
  const cfg = vscode.workspace.getConfiguration('symfonyTwig');
  return {
    templatesDir: cfg.get<string>('templatesDir', 'templates'),
    controllerDir: cfg.get<string>('controllerDir', 'src/Controller'),
    searchInPhp: cfg.get<boolean>('searchInPhp', true),
  };
}

// ============================================================
// Twig path → Controller file candidates
// ============================================================

function resolveControllerCandidates(
  twigRelPath: string,
  controllerDir: string
): string[] {
  const withoutExt = twigRelPath
    .replace(/\.html\.twig$/, '')
    .replace(/\.twig$/, '');

  const parts = withoutExt.split('/').filter(Boolean);
  const candidates: string[] = [];

  if (parts.length === 0) return candidates;

  if (parts.length >= 1) {
    const ctrlName = capitalize(parts[0]) + 'Controller.php';
    candidates.push(path.join(controllerDir, ctrlName));
  }

  if (parts.length >= 2) {
    const dir = parts.slice(0, -1).map(capitalize).join(path.sep);
    const ctrlName = capitalize(parts[parts.length - 1]) + 'Controller.php';
    candidates.push(path.join(controllerDir, dir, ctrlName));
  }

  if (parts.length >= 2) {
    const ctrlName = parts.map(capitalize).join('') + 'Controller.php';
    candidates.push(path.join(controllerDir, ctrlName));
  }

  for (let i = 1; i < parts.length; i++) {
    const dir = parts.slice(0, i).map(capitalize).join(path.sep);
    const ctrlName = capitalize(parts[i - 1]) + 'Controller.php';
    candidates.push(path.join(controllerDir, dir, ctrlName));
  }

  return [...new Set(candidates)];
}

function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ============================================================
// Reverse lookup: render() calls in PHP → template path
// ============================================================

async function searchRenderCalls(
  templateRelPath: string,
  controllerDir: string
): Promise<Array<{ file: string; line: number; match: string }>> {
  const results: Array<{ file: string; line: number; match: string }> = [];
  if (!fs.existsSync(controllerDir)) return results;

  const phpFiles = findPhpFiles(controllerDir);

  for (const phpFile of phpFiles) {
    const content = fs.readFileSync(phpFile, 'utf8');
    const lines = content.split('\n');

    lines.forEach((line: string, idx: number) => {
      const pattern = /render\s*\(\s*['"]([^'"]+)['"]/g;
      let m: RegExpExecArray | null;
      while ((m = pattern.exec(line)) !== null) {
        const found = m[1];
        if (found === templateRelPath || found.endsWith('/' + templateRelPath)) {
          results.push({ file: phpFile, line: idx + 1, match: found });
        }
      }
    });
  }

  return results;
}

// ============================================================
// Forward lookup: Controller file → Twig template candidates
// ============================================================

/**
 * Extracts all render('*.twig') paths from a PHP file with line numbers.
 */
function extractRenderPathsFromFile(
  phpFilePath: string
): Array<{ templatePath: string; line: number }> {
  const results: Array<{ templatePath: string; line: number }> = [];
  if (!fs.existsSync(phpFilePath)) return results;

  const content = fs.readFileSync(phpFilePath, 'utf8');
  const lines = content.split('\n');

  lines.forEach((line, idx) => {
    const pattern = /render\s*\(\s*['"]([^'"]+\.(?:html\.twig|twig))['"]/g;
    let m: RegExpExecArray | null;
    while ((m = pattern.exec(line)) !== null) {
      results.push({ templatePath: m[1], line: idx + 1 });
    }
  });

  return results;
}

/**
 * Derives likely Twig template paths from a Controller filename via naming convention.
 * e.g. src/Controller/FooController.php        → templates/foo/index.html.twig
 *      src/Controller/Admin/DashboardController.php → templates/admin/dashboard/index.html.twig
 */
function deriveTemplatesFromController(
  phpFilePath: string,
  controllerDir: string,
  templatesRoot: string
): string[] {
  const rel = path.relative(controllerDir, phpFilePath).replace(/\\/g, '/');
  const withoutSuffix = rel.replace(/Controller\.php$/, '');
  const parts = withoutSuffix.split('/').filter(Boolean);

  if (parts.length === 0) return [];

  const candidates: string[] = [];
  const dirParts = parts.map(p => p.toLowerCase());

  // e.g. Admin/Dashboard → templates/admin/dashboard/index.html.twig
  candidates.push(path.join(templatesRoot, ...dirParts, 'index.html.twig'));

  if (parts.length >= 2) {
    const dir = parts.slice(0, -1).map(p => p.toLowerCase()).join('/');
    const tplName = parts[parts.length - 1].toLowerCase();
    // templates/admin/dashboard.html.twig
    candidates.push(path.join(templatesRoot, dir, tplName + '.html.twig'));
    // templates/admin/index.html.twig
    candidates.push(path.join(templatesRoot, dir, 'index.html.twig'));
  }

  if (parts.length === 1) {
    // templates/foo.html.twig
    candidates.push(path.join(templatesRoot, parts[0].toLowerCase() + '.html.twig'));
  }

  return [...new Set(candidates)];
}

function findTwigFiles(dir: string): string[] {
  const files: string[] = [];
  if (!fs.existsSync(dir)) return files;

  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...findTwigFiles(full));
    } else if (
      entry.isFile() &&
      (entry.name.endsWith('.html.twig') || entry.name.endsWith('.twig'))
    ) {
      files.push(full);
    }
  }
  return files;
}

function findPhpFiles(dir: string): string[] {
  const files: string[] = [];
  if (!fs.existsSync(dir)) return files;

  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...findPhpFiles(full));
    } else if (entry.isFile() && entry.name.endsWith('.php')) {
      files.push(full);
    }
  }
  return files;
}

// ============================================================
// Open file and jump to line
// ============================================================

async function openFileAtLine(filePath: string, line?: number) {
  const uri = vscode.Uri.file(filePath);
  const doc = await vscode.workspace.openTextDocument(uri);
  const editor = await vscode.window.showTextDocument(doc);

  if (line !== undefined && line > 0) {
    const pos = new vscode.Position(line - 1, 0);
    editor.selection = new vscode.Selection(pos, pos);
    editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.InCenter);
  }
}

// ============================================================
// Command: Twig → Controller
// ============================================================

async function openControllerForCurrentTwig() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showWarningMessage('No active editor.');
    return;
  }

  const root = getWorkspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('No workspace folder is open.');
    return;
  }

  const { templatesDir, controllerDir, searchInPhp } = getConfig();
  const templatesRoot = path.join(root, templatesDir);
  const controllerRoot = path.join(root, controllerDir);
  const filePath = editor.document.uri.fsPath;

  if (!filePath.startsWith(templatesRoot)) {
    vscode.window.showWarningMessage(
      `This file is not inside the ${templatesDir}/ directory.`
    );
    return;
  }

  const twigRelPath = path.relative(templatesRoot, filePath).replace(/\\/g, '/');

  await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: 'Searching for Controller...' },
    async () => {
      const candidates = resolveControllerCandidates(twigRelPath, controllerRoot);
      const existing = candidates.filter(fs.existsSync);

      let renderResults: Array<{ file: string; line: number; match: string }> = [];
      if (searchInPhp) {
        renderResults = await searchRenderCalls(twigRelPath, controllerRoot);
      }

      const items: vscode.QuickPickItem[] = [];

      for (const r of renderResults) {
        const rel = path.relative(root, r.file);
        items.push({
          label: `$(search) ${path.basename(r.file)}`,
          description: `Line ${r.line}  — render('${r.match}')`,
          detail: rel,
          ...({ file: r.file, line: r.line } as unknown as object),
        });
      }

      for (const f of existing) {
        const rel = path.relative(root, f);
        if (!renderResults.some(r => r.file === f)) {
          items.push({
            label: `$(file-code) ${path.basename(f)}`,
            description: 'Matched by naming convention',
            detail: rel,
            ...({ file: f, line: undefined } as unknown as object),
          });
        }
      }

      if (items.length === 0) {
        vscode.window.showInformationMessage(
          `No Controller found for "${twigRelPath}".\nSearch path: ${controllerRoot}`
        );
        return;
      }

      if (items.length === 1) {
        const item = items[0] as { file: string; line?: number } & vscode.QuickPickItem;
        await openFileAtLine(item.file, item.line);
        return;
      }

      const selected = await vscode.window.showQuickPick(items, {
        placeHolder: `Select Controller for "${twigRelPath}"`,
        matchOnDetail: true,
      });

      if (selected) {
        const s = selected as { file: string; line?: number } & vscode.QuickPickItem;
        await openFileAtLine(s.file, s.line);
      }
    }
  );
}

// ============================================================
// Command: Selection → Controller
// ============================================================

async function openControllerFromSelection() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return;

  const selection = editor.selection;
  let templatePath = editor.document.getText(selection).trim().replace(/['"]/g, '');

  if (!templatePath) {
    const line = editor.document.lineAt(selection.active.line).text;
    const m = /['"]([^'"]+\.(?:html\.twig|twig))['"]/g.exec(line);
    if (m) {
      templatePath = m[1];
    }
  }

  if (!templatePath) {
    vscode.window.showWarningMessage(
      'Please select a template path (e.g. admin/index.html.twig) before running this command.'
    );
    return;
  }

  const root = getWorkspaceRoot();
  if (!root) return;

  const { controllerDir, searchInPhp } = getConfig();
  const controllerRoot = path.join(root, controllerDir);

  await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: `Searching Controller for "${templatePath}"...` },
    async () => {
      const candidates = resolveControllerCandidates(templatePath, controllerRoot);
      const existing = candidates.filter(fs.existsSync);

      let renderResults: Array<{ file: string; line: number; match: string }> = [];
      if (searchInPhp) {
        renderResults = await searchRenderCalls(templatePath, controllerRoot);
      }

      const allFiles = [
        ...renderResults.map(r => ({ file: r.file, line: r.line, label: `render() reference — line ${r.line}` })),
        ...existing
          .filter(f => !renderResults.some(r => r.file === f))
          .map(f => ({ file: f, line: undefined, label: 'Matched by naming convention' })),
      ];

      if (allFiles.length === 0) {
        vscode.window.showInformationMessage(`No Controller found for "${templatePath}".`);
        return;
      }

      if (allFiles.length === 1) {
        await openFileAtLine(allFiles[0].file, allFiles[0].line);
        return;
      }

      const items = allFiles.map(f => ({
        label: `$(file-code) ${path.basename(f.file)}`,
        description: f.label,
        detail: path.relative(root, f.file),
        file: f.file,
        line: f.line,
      }));

      const selected = await vscode.window.showQuickPick(items, {
        placeHolder: `Select Controller for "${templatePath}"`,
      });

      if (selected) {
        await openFileAtLine(selected.file, selected.line);
      }
    }
  );
}

// ============================================================
// Command: Controller → Twig  (NEW)
// ============================================================

async function openTwigForCurrentController() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showWarningMessage('No active editor.');
    return;
  }

  const root = getWorkspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage('No workspace folder is open.');
    return;
  }

  const { templatesDir, controllerDir } = getConfig();
  const templatesRoot = path.join(root, templatesDir);
  const controllerRoot = path.join(root, controllerDir);
  const filePath = editor.document.uri.fsPath;

  if (!filePath.startsWith(controllerRoot)) {
    vscode.window.showWarningMessage(
      `This file is not inside the ${controllerDir}/ directory.`
    );
    return;
  }

  await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: 'Searching for Twig templates...' },
    async () => {
      const items: vscode.QuickPickItem[] = [];
      const seenFiles = new Set<string>();

      // Priority 1: render() calls found directly in the Controller file
      const renderPaths = extractRenderPathsFromFile(filePath);
      for (const { templatePath, line } of renderPaths) {
        const absPath = path.join(templatesRoot, templatePath);
        if (fs.existsSync(absPath) && !seenFiles.has(absPath)) {
          seenFiles.add(absPath);
          items.push({
            label: `$(search) ${path.basename(absPath)}`,
            description: `render() on line ${line}  — '${templatePath}'`,
            detail: path.relative(root, absPath),
            ...({ file: absPath, line: undefined } as unknown as object),
          });
        }
      }

      // Priority 2: naming convention
      const conventionPaths = deriveTemplatesFromController(filePath, controllerRoot, templatesRoot);
      for (const absPath of conventionPaths) {
        if (fs.existsSync(absPath) && !seenFiles.has(absPath)) {
          seenFiles.add(absPath);
          items.push({
            label: `$(file-code) ${path.basename(absPath)}`,
            description: 'Matched by naming convention',
            detail: path.relative(root, absPath),
            ...({ file: absPath, line: undefined } as unknown as object),
          });
        }
      }

      // Priority 3: fuzzy base-name match across all twig files
      if (items.length === 0) {
        const controllerBaseName = path.basename(filePath, '.php')
          .replace(/Controller$/, '')
          .toLowerCase();

        const allTwig = findTwigFiles(templatesRoot);
        for (const absPath of allTwig) {
          const twigBaseName = path
            .basename(absPath)
            .replace(/\.html\.twig$/, '')
            .replace(/\.twig$/, '');
          const twigDir = path.dirname(absPath);
          if (
            twigBaseName.toLowerCase() === controllerBaseName ||
            twigDir.toLowerCase().endsWith(path.sep + controllerBaseName) ||
            twigDir.toLowerCase().endsWith('/' + controllerBaseName)
          ) {
            if (!seenFiles.has(absPath)) {
              seenFiles.add(absPath);
              items.push({
                label: `$(file) ${path.basename(absPath)}`,
                description: 'Fuzzy name match',
                detail: path.relative(root, absPath),
                ...({ file: absPath, line: undefined } as unknown as object),
              });
            }
          }
        }
      }

      if (items.length === 0) {
        vscode.window.showInformationMessage(
          `No Twig templates found for "${path.basename(filePath)}".\nSearch path: ${templatesRoot}`
        );
        return;
      }

      if (items.length === 1) {
        const item = items[0] as { file: string; line?: number } & vscode.QuickPickItem;
        await openFileAtLine(item.file, item.line);
        return;
      }

      const selected = await vscode.window.showQuickPick(items, {
        placeHolder: `Select Twig template for "${path.basename(filePath)}"`,
        matchOnDetail: true,
      });

      if (selected) {
        const s = selected as { file: string; line?: number } & vscode.QuickPickItem;
        await openFileAtLine(s.file, s.line);
      }
    }
  );
}

// ============================================================
// Command: Selection in PHP → Twig  (NEW)
// ============================================================

async function openTwigFromSelection() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return;

  const selection = editor.selection;
  let templatePath = editor.document.getText(selection).trim().replace(/['"]/g, '');

  if (!templatePath) {
    const line = editor.document.lineAt(selection.active.line).text;
    const m = /['"]([^'"]+\.(?:html\.twig|twig))['"]/g.exec(line);
    if (m) {
      templatePath = m[1];
    }
  }

  if (!templatePath) {
    vscode.window.showWarningMessage(
      'Please select or place the cursor on a template path (e.g. admin/index.html.twig).'
    );
    return;
  }

  const root = getWorkspaceRoot();
  if (!root) return;

  const { templatesDir } = getConfig();
  const templatesRoot = path.join(root, templatesDir);
  const absPath = path.join(templatesRoot, templatePath);

  if (fs.existsSync(absPath)) {
    await openFileAtLine(absPath);
  } else {
    vscode.window.showInformationMessage(
      `Template not found: ${path.relative(root, absPath)}`
    );
  }
}

// ============================================================
// activate / deactivate
// ============================================================

export function activate(context: vscode.ExtensionContext) {
  console.log('symfony-twig-goto-controller activated');

  context.subscriptions.push(
    vscode.commands.registerCommand('symfonyTwig.openController', openControllerForCurrentTwig),
    vscode.commands.registerCommand('symfonyTwig.openControllerFromSelection', openControllerFromSelection),
    vscode.commands.registerCommand('symfonyTwig.openTwig', openTwigForCurrentController),
    vscode.commands.registerCommand('symfonyTwig.openTwigFromSelection', openTwigFromSelection)
  );
}

export function deactivate() {}
